var hr_yValues = [];
var spo2_yValues = [];
var sample_time = [];

function displayChart(){
    try{
        const d = new Date();

        let window_v = document.getElementById("window").value;

        hr_yValues.push(heart_rate);
        spo2_yValues.push(spo2_rate);
        sample_time.push(d.getHours()+":"+d.getMinutes()+":"+d.getSeconds());
        
        console.log(window_v);
        console.log(window_v<sample_time.length)

        if(window_v!=0 && window_v<sample_time.length){
            hr_yValues.shift();
            spo2_yValues.shift();
            sample_time.shift();
            while(window_v<sample_time.length){
                hr_yValues.shift();
                spo2_yValues.shift();
                sample_time.shift();
            }
        }

        gtd.data.labels = sample_time;
        gtd.data.datasets.data = hr_yValues;
        gtd.update();

        std.data.labels = sample_time;
        std.data.datasets.data = spo2_yValues;
        std.update();
    }
    catch(error){console.error(`Something went wrong. ${error}`); document.getElementById("errorLog").innerHTML = error;};
};

var gtd = new Chart(
    "hr_graph",
    {
        type: "line",
        data: {
            labels: sample_time,
            datasets: [{
                backgroundColor: "rgba(0,0,50,0.5)",
                borderColor: "rgba(0,0,50,1.0)",
                data: hr_yValues
            }]
        },
        options: {
            legend: {display: false},
            scales: {
                yAxes: [{ticks: {min: 40, max: 180}}],
            },
            Animation: true,
            decimation: true
        }
    }
);

var std = new Chart(
    "spo2_graph",
    {
        type: "line",
        data: {
            labels: sample_time,
            datasets: [{
                backgroundColor: "rgba(0,0,50,0.5)",
                borderColor: "rgba(0,0,50,1.0)",
                data: spo2_yValues
            }]
        },
        options: {
            legend: {display: false},
            scales: {
                yAxes: [{ticks: {min: 0, max: 100}}],
            },
            Animation: true,
            decimation: true
        }
    }
);